import React, { useEffect, useState, useRef } from "react";
import SSM_A_L2_1 from "../../../assets/level-2/audio/SSM_A_L2_1.mp3";
import SSM_A_L2_2 from "../../../assets/level-2/audio/SSM_A_L2_2.mp3";
import SSM_A_L2_3_MF from "../../../assets/level-2/audio/SSM_A_L2_3.mp3";
import SSM_A_L2_4 from "../../../assets/level-2/audio/SSM_A_L2_4.mp3";
import SSM_A_L2_11 from "../../../assets/level-2/audio/SSM_A_L2_11.mp3";
import For_level_completion from "../../../assets/common/audio/For_level_completion.mp3";
import silence_no_sound_4_3_Sec from "../../../assets/common/audio/silence_no_sound_4_3_Sec.mp3";
import GL_A_19 from "../../../assets/common/audio/GL_A_19.mp3";


import Hand_Cursor3 from "../../../assets/common/textures/interactions/Hand_Cursor3.png";
import inactive_audio_replay from "../../../assets/common/textures/interactions/inactive_audio_replay.png";
import Audio_Replay from "../../../assets/common/textures/interactions/Audio_Replay.png";
import lets_play from "../../../assets/common/textures/interactions/lets_play.png";
import Header from "../common/header/Header";
import Mascot from "../common/Mascot";
import SkipButton from "../../../assets/common/textures/interactions/skip.png";
import HomeContinueOrPicknew from "../common/global-buttons/home-continue-or-picknew/HomeContinueOrPicknew";
import "./index.scss";
import bgImage from "../../../assets/common/images/repeatable_background_level_0.png";
import { level2DemoData, level2Data } from "../../constants/level2";
import { useAudioManager } from "../../AudioManagerContext";
import AudioRecorderComponent from "../common/audio-recorder/AudioRecorderComponent";
import { playConfetti } from "../../utils/confetti";
import SkipLevelContinueOrPlayNext from "../common/global-buttons/SkipLevelContinueOrPlayNext";
import LevelPlayAgainOrPlayNext from "../common/global-buttons/LevelPlayAgainOrPlayNext";
import HintPlayAgainOrPlayGame from "../common/global-buttons/hint-playagain-or-playgame/HintPlayagainOrPlaygame";
import HintSkipContinueOrExit from "../common/global-buttons/HintSkipContinueOrExit";
import EndPlayAgainOrPicknew from "../common/global-buttons/end-playagain-or-picknew/EndPlayAgainOrPicknew";

const firstSound = new Audio(SSM_A_L2_1);
const secondSound = new Audio(SSM_A_L2_2);
const thirdSound = new Audio(SSM_A_L2_3_MF);
const fourthSound = new Audio(SSM_A_L2_4);
const finalSound = new Audio(SSM_A_L2_11);
const silence_5 = new Audio(silence_no_sound_4_3_Sec);
const suggestInstruction = new Audio(GL_A_19)

const Index = ({
  setCurrentLevelState,
  enableSkip,
  updatePostData,
  updateSetData,
}) => {
  const { currentAudio, playContextAudio, pauseContextAudio } =
    useAudioManager();
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [startPlay, setStartPlay] = useState(true);
  const [showMascot, setShowMascot] = useState(false);
  const [showSecondMascot, setShowSecondMascot] = useState(false);
  const [diplayBgImage, setDiplayBgImage] = useState(false);
  const [isHomeContinueOrPicknew, setIsHomeContinueOrPicknew] = useState(false);
  const [showGrid, setShowGrid] = useState(false);
  const [levelPresentionData, setLevelPresentionData] = useState({ ...level2DemoData });
  const [level2SetData, setlevel2SetData] = useState(level2Data[0]);
  const [wrongAnswer, setWrongAnswer] = useState(false);

  const [showoObject, setShowoObject] = useState(false);
  const [showMike, setShowMike] = useState(false);
  const [showSpecificImage, setShowSpecificImage] = useState(false);
  const [showHandCursor, setShowHandCursor] = useState(false);
  const [showCorrectImage, setShowCorrectImage] = useState(false);
  const [showAudioReplayCursor, setShowAudioReplayCursor] = useState(false);
  const [startset, setStartset] = useState(false);
  const [correctAnswer, setCorrectAnswer] = useState(false);
  const setStartTime = useRef(0);
  const setEndTime = useRef(0);
  const [gameIndex, setGameIndex] = useState(() => {
    let temp = JSON.parse(localStorage.getItem("currentSet"));
    return temp ? temp?.level2 : 0;
  });
  const [levelCompleted, setLevelCompleted] = useState(false);
  const [showReplaySkip, setShowReplaySkip] = useState(false);
  const [showReplayLevelSkip, setShowReplayLevelSkip] = useState(false);
  const [showHintPlayAgain, setShowHintPlayAgain] = useState(false);
  const [showSkipButton, setShowSkipButton] = useState(false);
  const [showHintSkip, setShowHintSkip] = useState(false);
  const [isHintActive, setIsHintActive] = useState(false);

  const [maxLevelStored, setMaxLevelStored] = useState(
    Number(localStorage.getItem("maxLevel") || 0)
  );
  const [currentLevelStored, setCurrentLevelStored] = useState(
    Number(localStorage.getItem("currentLevel") || 2)
  );
  const [presentationCompletedTill, setPresentationCompletedTill] = useState(
    Number(localStorage.getItem("presentationCompletedTill") || 0)
  );

  /*************onclick play button/First Audio****************/
  const PlayButton = (playHintCalled) => {
    setStartTime.current = performance.now();
    updatePostData("setStart", { level: 2, time: 0 });
    setStartPlay(false);
    setShowMascot(true);
    playContextAudio(firstSound, setIsAudioPlaying);
    firstSound.onended = () => {
      handleFirstAudioEnd(playHintCalled);
    };
  };

  /*************First Audio End****************/
  const handleFirstAudioEnd = (playHintCalled) => {
    setShowMascot(false);
    setShowSecondMascot(true);
    setShowGrid(true);
    playContextAudio(secondSound, setIsAudioPlaying);
    secondSound.onended = () => {
      handleSecondAudioEnd1(playHintCalled);
    };
  };

  /*************Second Audio End****************/
  const handleSecondAudioEnd1 = (playHintCalled) => {
    setShowSecondMascot(false);
    // setShowSpecificImage(false);
    setShowoObject(true);
    playContextAudio(silence_5, setIsAudioPlaying);
    silence_5.onended = () => {
      handleSecondAudioEnd(playHintCalled);
    };
  };

  /*************Second Audio End****************/
  const handleSecondAudioEnd = (playHintCalled) => {
    // setShowSecondMascot(false);
    // setShowSpecificImage(true);
    setShowMike(true);
    setShowoObject(false);
    playContextAudio(fourthSound, setIsAudioPlaying);
    fourthSound.onended = () => {
      handleThirdAudioEnd(playHintCalled);
    };
  };


  /*************Third Audio End****************/
  const handleThirdAudioEnd = (playHintCalled) => {
    setShowSpecificImage(true);
    setShowHandCursor(true);
    thirdSound.onended = () => {
      hadleFourthAudioEnd(playHintCalled);
    };
    playContextAudio(thirdSound, setIsAudioPlaying);

  };

  
  const hadleFourthAudioEnd = (playHintCalled) => {
    setShowHandCursor(false);
    setShowMike(false);
    setShowSpecificImage(false);
    setShowCorrectImage(true);
    setShowoObject(true)
    finalSound.onended = () => {
      instruction(playHintCalled);
    };
    playContextAudio(finalSound, setIsAudioPlaying);
  };

  
  /*************Third Audio End****************/
  const instruction = (playHintCalled) => {
    setShowAudioReplayCursor(true);
    suggestInstruction.onended = () => {
      setShowAudioReplayCursor(false);
      presentationComplete();
      if (playHintCalled) {
        setShowHintPlayAgain(true);
        setDiplayBgImage(true);
      } else {
        
        callStartSet();
      }
    };
    playContextAudio(suggestInstruction, setIsAudioPlaying);
  };



  const callStartSet = () => {
    setIsHintActive(true);
    localStorage.setItem("presentationCompletedTill", 2);
    setShowGrid(false);
    setShowoObject(true);
    setCorrectAnswer(false);
    setStartset(true);

    const audio = new Audio(level2SetData.question);
    playContextAudio(audio, setIsAudioPlaying);
    audio.onended = () => {
      setShowoObject(false);
      setIsRecording(false);
    };
  };

  const presentationComplete = () => {
    presentationCompletedTill <= currentLevelStored &&
      localStorage.setItem("presentationCompletedTill", currentLevelStored);
    setPresentationCompletedTill(
      Number(localStorage.getItem("presentationCompletedTill") || 0)
    );
    updatePostData("setStart", { level: 2, time: 0 });
    setStartTime.current = performance.now();
  };

  /*************Handle Home Button Click****************/
  const handleHomeButtonClick = () => {
    pauseContextAudio(currentAudio, setIsAudioPlaying);
    setDiplayBgImage(true);
    setIsHomeContinueOrPicknew(true);
  };

  const onStopRecording = async (result, referenceText) => {
    const answerAudio = new Audio(level2SetData.answer);
    await result
      .then((res) => {
        if (
          res?.success == true &&
          res?.data?.evaluatedText?.replace(/\./g, "")?.toLowerCase() ==
            referenceText
        ) {
          setCorrectAnswer(true);
          setShowoObject(true);
          playContextAudio(answerAudio, setIsAudioPlaying);
        } else {
          const wrongAnswerAudio = new Audio(level2SetData.wrong_answer);
          setWrongAnswer(true);
          wrongAnswerAudio.onended = () => {
            setWrongAnswer(false);
            setIsRecording(false);
          };
          playContextAudio(wrongAnswerAudio, setIsAudioPlaying);
        }
      })
      .catch((err) => {
        const wrongAnswerAudio = new Audio(level2SetData.wrong_answer);
        setWrongAnswer(true);
        wrongAnswerAudio.onended = () => {
          setWrongAnswer(false);
          setIsRecording(false);
        };
        playContextAudio(wrongAnswerAudio, setIsAudioPlaying);
      });
    answerAudio.onended = () => {
      setGameIndex((prevIndex) => prevIndex + 1);
    };
  };

  const PlayAgainButton = () => {
    setDiplayBgImage(false);
    updatePostData("setStart", { level: 2, time: 0 });
    setShowReplaySkip(true);
    setLevelCompleted(false);
    setGameIndex(0);
    setStartset(true);
    setShowMascot(false);
    setShowSecondMascot(false);
  };
  const handleHintButtonClick = () => {
    updatePostData("presenationStart", { level: 2, time: 0 });
    pauseContextAudio(currentAudio, setIsAudioPlaying);
    setShowGrid(false);
    setStartset(false);
    setIsHintActive(false);
    setShowSkipButton(true);
    PlayButton(true);
    // setShowSpecificImage(false);
    setShowCorrectImage(false);
  };

  useEffect(() => {
    if (presentationCompletedTill >= 2 && currentLevelStored == 2) {
      if (gameIndex < level2Data.length) {
        setCorrectAnswer(false);
        setlevel2SetData(level2Data[gameIndex]);
        gameIndex <= level2Data.length && updateSetData('level2', gameIndex);
        const audio = new Audio(level2Data[gameIndex].question);
        playContextAudio(audio, setIsAudioPlaying);
        audio.onended = () => {
          setIsRecording(false);
          setShowoObject(false);
          // setShowMike(true);
          console.log(correctAnswer, showoObject);
        };
      }
      console.log("gameIndex", gameIndex);
      if (gameIndex === level2Data.length) {
        updateSetData('level2', 0);
        setDiplayBgImage(true);
        playConfetti();
        setLevelCompleted(true);
        localStorage.setItem("gameCompletedTill", 2);
        const levelCompletedAudio = new Audio(For_level_completion);
        playContextAudio(levelCompletedAudio, setIsAudioPlaying);
      }
    }
  }, [gameIndex]);

  useEffect(() => {
    const presentationCompletedTill = Number(
      localStorage.getItem("presentationCompletedTill")
    );
    if (presentationCompletedTill >= 2) {
      setStartPlay(false);
      setShowMascot(false);
      setShowGrid(false);
      setShowSpecificImage(true);
      setShowReplaySkip(true);
      setIsHintActive(true);
      setStartset(true);
      setShowoObject(true);
    } else {
      setStartPlay(true);
      PlayButton(false);
    }
  }, []);

  const playRepeatingAudio = () => {
    const reapetingAudio = new Audio(level2Data[gameIndex].question);
    reapetingAudio.addEventListener("play", () => {
      // setIsButtonDisabled(true);
        setCorrectAnswer(false);
        setShowoObject(true);

    });
    reapetingAudio.onended = () => {
      setShowoObject(false);
      setIsRecording(false);
      // setIsButtonDisabled(false);
    };
    playContextAudio(reapetingAudio, setIsAudioPlaying);
  };

  return (
    <div className="level0Style">
      <div className="level0_div">
        <Header
          // isMusicPlaying={isMusicPlaying}
          isHintActive={
            isHintActive && presentationCompletedTill >= 1 ? true : false
          }
          isBackActive={isHintActive && presentationCompletedTill >= 1 ? true : false}
          onHomeButtonClick={handleHomeButtonClick}
          onHintButtonClick={handleHintButtonClick}
          PlayAgainButton={PlayAgainButton}
          setIsAudioPlaying = {setIsAudioPlaying}
          playAudio={playContextAudio}
          pauseAudio={pauseContextAudio}
          currentAudio={currentAudio}
          setDiplayBgImage = {setDiplayBgImage}
          selectedLevel={1}
          // startPlay={startPlay}
          score={
            localStorage.getItem("rewardPoints")
              ? localStorage.getItem("rewardPoints")
              : 0
          }
          percentFill={localStorage.getItem("gameCompletedTill") == 4 ? 100 : 0}
        />
        {diplayBgImage && (
          <div
            style={{
              zIndex: "10",
              backgroundSize: "cover",
              backgroundRepeat: "no-repeat",
              backgroundPosition: "bottom",
              position: "fixed",
              top: 0,
              height: "100vh",
              width: "100%",
              backgroundImage: `url(${bgImage})`,
            }}
          ></div>
        )}


        <div className="d-flex justify-content-end">
          <div className="audio_replay_div">
            <button
              data-exclude-click="true"
              className="btn p-0 instructionButton"
              type="button"
              onClick={() => {}}
              disabled={isAudioPlaying}
              // style={{opacity: '1 !important'}}
            >
              {!isAudioPlaying ? (
                <img
                  src={Audio_Replay}
                  className="img-fluid  Audio_Replay_Button"
                  alt="Audio_Replay"
                  data-exclude-click="true"
                />
              ) : (
                <img
                  src={inactive_audio_replay}
                  className="img-fluid Audio_Replay_Button"
                  alt="Audio_Replay"
                />
              )}
            </button>
            {showAudioReplayCursor && (
              <img
                src={Hand_Cursor3}
                className="audio_replay"
                alt="hand_cursor"
              />
            )}
          </div>
        </div>
        {/* {showReplaySkip && !startPlay && (
          <img
            src={SkipButton}
            data-exclude-click="true"
            style={{ position: "fixed", bottom: 45, right: "1%", width: 34 }}
            onClick={() => {
              pauseContextAudio(currentAudio, setIsAudioPlaying);
              setDiplayBgImage(true);
              setShowReplayLevelSkip(true);
            }}
          />
        )} */}
        {showSkipButton && (
          <img
            data-exclude-click="true"
            src={SkipButton}
            style={{ position: "fixed", bottom: 45, right: "1%", width: 34 }}
            onClick={() => {
              pauseContextAudio(currentAudio, setIsAudioPlaying);
              setDiplayBgImage(true);
              setShowHintSkip(true);
            }}
          />
        )}
        {showMascot && <Mascot />}

        {showSecondMascot && <Mascot showMascot2={true} />}

        {showGrid && (
          <div className="vegetableGridContainer">
            <div className="vegetablesGrid0">
              {/* {level2Data.map((item, index) => ( */}
              <div
                className="containerStyle0"
                key={levelPresentionData.id}
                style={
                  showSpecificImage || showCorrectImage
                    ? {
                      position: "relative",
                      display: "flex",
                      flexDirection: "column",
                      height: "83vh",
                      alignItems: "center",
                      justifyContent: "center",
                      gap: "15px"
                      }
                    : {
                        position: "relative",
                        display: "flex",
                        flexDirection: "column",
                        height: "83vh",
                        alignItems: "center",
                        justifyContent: "center"
                      }
                }
              >
                <div
                  style={!(showSpecificImage || showCorrectImage) || showMike ? {
                    position: "relative",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center"
                    } : 
                    {
                      position: "relative",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "50%",
                      
                    }
                  }
                >
                  {!showMike && (
                    <img
                      src={levelPresentionData.image_place_holder}
                      alt="image_place_holder"
                      style={{ height: "98%" }}
                    />
                  )}

                  {showoObject && (
                  <img
                    src={levelPresentionData.image}
                    className="actual_image"
                    alt="Big Image"
                  />
                  )}
                </div>
                {showMike && (
                  <img
                    src={levelPresentionData.mic_button}
                    alt="mic button"
                  />
                )}
                {showHandCursor && (
                  <img
                    src={levelPresentionData.hand_cusrsor}
                    style={{
                      position: "absolute",
                      height: "28%",
                      bottom: "26%",
                      marginLeft: "75px",
                      transform: "rotate(-22deg)",
                    }}
                    alt="mic button"
                  />
                )}
                {showCorrectImage && (
                  <>
                  <img
                    src={levelPresentionData.demarcation_line}
                    style={{ width: "80%", height: "1.7px" }}
                    className="hand_cursor"
                    alt="hand_cursor"
                  />
                  <img
                    src={levelPresentionData.correct_image}
                    style={{ height: "33%" }}
                    alt="correct image"
                  />
                  </>
                )}
              </div>
              {/* ))} */}
            </div>
          </div>
        )}
        {startset && (
          <div className="vegetableGridContainer">
          <div className="vegetablesGrid0">
            {/* {level2Data.map((item, index) => ( */}
            <div
              className="containerStyle0"
              key={level2SetData.id}
              style={
                showSpecificImage || showCorrectImage
                  ? {
                    position: "relative",
                    display: "flex",
                    flexDirection: "column",
                    height: "83vh",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "15px"
                    }
                  : {
                      position: "relative",
                      display: "flex",
                      flexDirection: "column",
                      height: "83vh",
                      alignItems: "center",
                      justifyContent: "center"
                    }
              }
            >
              <div
                style={!(showSpecificImage || showCorrectImage) || !correctAnswer ? {
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center"
                  } : 
                  {
                    position: "relative",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    height: "50%",
                    
                  }
                }
              >
                {showoObject && (
                  <>
                  <img
                 src={level2SetData.image_place_holder}
                 alt="image_place_holder"
                 style={{ height: "98%" }}
                />
                <img
                  src={level2SetData.image}
                  className="actual_image"
                  alt="Big Image"
                />
                  </>

                )}
              </div>
              {!(correctAnswer || showoObject) && (  // if you write !correctAnswer || !showoObject will not work 
                <AudioRecorderComponent
                  id="audio_mic_comp"
                  wrongAnswer={wrongAnswer}
                  referenceText={level2SetData.text}
                  onStopRecording={onStopRecording}
                  setIsRecording={setIsRecording}
                  isRecording={isRecording}
                  level = {2}
              />
              )}
              {correctAnswer && (
                <>
                <img
                  src={level2SetData.demarcation_line}
                  style={{ width: "80%", height: "1.7px" }}
                  className="hand_cursor"
                  alt="hand_cursor"
                />
                <img
                  src={level2SetData.correct_image}
                  style={{ height: "33%" }}
                  alt="correct image"
                />
                </>
              )}
            </div>
            {/* ))} */}
          </div>
        </div>
        )}
      </div>
      {/* {showReplayLevelSkip && (
        <SkipLevelContinueOrPlayNext
          setCurrentLevelState={setCurrentLevelState}
          setShowReplaySkip={setShowReplaySkip}
          showReplaySkip={showReplaySkip}
          setIsAudioPlaying={setIsAudioPlaying}
          level={2}
          isAudioPlaying={isAudioPlaying}
          setShowReplayLevelSkip={setShowReplayLevelSkip}
          setDiplayBgImage={setDiplayBgImage}
          playAudio={playContextAudio}
          pauseAudio={pauseContextAudio}
          currentAudio={currentAudio}
          onContinueAfterLevelComplete={() => {
            playRepeatingAudio();
          }}
        />
      )} */}
      {levelCompleted && (
        <EndPlayAgainOrPicknew
          PlayAgainButton={PlayAgainButton}
          setCurrentLevelState={setCurrentLevelState}
          level={2}
          setIsAudioPlaying={setIsAudioPlaying}
          playAudio={playContextAudio}
          pauseAudio={pauseContextAudio}
          currentAudio={currentAudio}
          setDiplayBgImage={setDiplayBgImage}
        />
      )}

      {isHomeContinueOrPicknew && (
        <HomeContinueOrPicknew
          setIsHomeContinueOrPicknew={setIsHomeContinueOrPicknew}
          playAudio={playContextAudio}
          pauseAudio={pauseContextAudio}
          currentAudio={currentAudio}
          setIsAudioPlaying={setIsAudioPlaying}
          onClose={(audio) => {
            setDiplayBgImage(false);
            playContextAudio(audio, setIsAudioPlaying);
          }}
        />
      )}

      {showHintPlayAgain && (
        <HintPlayAgainOrPlayGame
          setShowHintPlayAgain={setShowHintPlayAgain}
          setIsAudioPlaying={setIsAudioPlaying}
          setStartset={setStartset}
          handleHintButtonClick={handleHintButtonClick}
          setShowSkipButton={setShowSkipButton}
          setDiplayBgImage={setDiplayBgImage}
          playAudio={playContextAudio}
          pauseAudio={pauseContextAudio}
          currentAudio={currentAudio}
          onPlayTheGame={() => {
            pauseContextAudio(currentAudio, setIsAudioPlaying);
            // playRepeatingAudio();
            callStartSet();
          }}
        />
      )}

      {showHintSkip && (
        <HintSkipContinueOrExit
          setStartset={setStartset}
          setIsAudioPlaying={setIsAudioPlaying}
          setShowMascot={setShowMascot}
          setShowGrid={setShowGrid}
          setShowSecondMascot={setShowSecondMascot}
          setShowSkipButton={setShowSkipButton}
          setIsHintActive={setIsHintActive}
          setShowHintSkip={setShowHintSkip}
          setDiplayBgImage={setDiplayBgImage}
          playAudio={playContextAudio}
          pauseAudio={pauseContextAudio}
          currentAudio={currentAudio}
          onContinue={(audio) => {
            playContextAudio(audio, setIsAudioPlaying);
          }}
          onExit={() => {
            setShowSpecificImage(true);
            playRepeatingAudio();
          }}
        />
      )}
    </div>
  );
};

export default Index;
