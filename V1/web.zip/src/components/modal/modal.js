import React, { useState } from "react";
import "./modal.css"

const Modal = ({ children, showModal, setShowModal }) => {
    return (
        <>
            {
                showModal.display && (
                    <div className="modalStyle">
                        <div className="modalContainer">
                            {children}
                        </div>
                    </div>
                ) || (
                    <div />
                )
            }
        </>

    )
}

export default Modal;