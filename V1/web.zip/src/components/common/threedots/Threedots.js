import React from 'react'
import './Threedots.css';


const Threedots = () => {
    return (
        <>
            {/* <div className="col-3 three_dot_div">
                <div className="snippet three_dot_div" data-title="dot-elastic">
                    <div className="stage">
                        <div className="dot-elastic"></div>
                    </div>
                </div>
            </div> */}
            <div className="col-3 three_dot_div">
                <div className="snippet three_dot_div" data-title="dot-pulse">
                    <div className="stage">
                        <div className="dot-pulse"></div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Threedots