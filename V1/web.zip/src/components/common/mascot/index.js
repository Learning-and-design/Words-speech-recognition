import React from 'react';
import Threedots from '../threedots/Threedots';
import Speech_Bubble from "../../../../assets/common/textures/interactions/Speech_Bubble.png";
import Speech_Bubble_2 from "../../../../assets/common/textures/interactions/Speech_Bubble_2.png";
import Mascot3 from "../../../../assets/common/textures/mascot/Mascot3.png";
import Mascot1 from "../../../../assets/common/textures/mascot/Mascot1.png";
import './index.css';

const Mascot = ({ showMascot2 = false }) => {
    return (
        <div className="mascot_center float-right" style={!showMascot2 ? { display: 'flex', zIndex: 1 } : { display: 'flex', flexDirection: 'row-reverse', left: '75%', zIndex: 1 }}>
            {!showMascot2 ? (
                <>
                    <img src={Mascot3} className="play_img img-fluid" alt="mascot1" />
                    <div style={{ position: 'absolute', display: 'flex', justifyContent: 'center', left: '90%', top: '-30%' }}>
                        <div className='three-dot-style'>
                            <Threedots />
                        </div>
                        <div>
                            <img
                                src={Speech_Bubble}
                                alt="Speech_Bubble"
                                className="right_muscot"
                            />
                        </div>
                    </div>
                </>
            ) : (
                <>
                    <img src={Mascot1} className="Mascot1_play_img img-fluid" alt="mascot1" />
                    <div style={{ position: 'absolute', display: 'flex', justifyContent: 'center', right: '70%', top: '-30%' }}>
                        <div className='three-dot-style'>
                            <Threedots />
                        </div>
                        <div>
                            <img
                                src={Speech_Bubble_2}
                                alt="Speech_Bubble"
                                className="right_muscot"
                            />
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default Mascot;
