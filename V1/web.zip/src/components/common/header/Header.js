import React, { useState, useEffect } from 'react';
import Home from '../../../../assets/common/textures/interactions/Home.png';
import Back from '../../../../assets/common/textures/interactions/Back.png';
import Back_Inactive from '../../../../assets/common/textures/interactions/Back_Inactive.png';
import Progress_bar_Type_1 from '../../../../assets/common/textures/interactions/Progress_bar_Type_1.png';
import Music from '../../../../assets/common/textures/interactions/Music.png';
import Music_Mute from '../../../../assets/common/textures/interactions/Music_Mute.png';
import Hint from '../../../../assets/common/textures/interactions/Hint.png';
import Hint_Inactive from '../../../../assets/common/textures/interactions/Hint_Inactive.png';
import Rewards from '../../../../assets/common/textures/interactions/Rewards.png';
import "./Header.css";
import ProgessBar from '../progress/Progress';
import LevelContinueOrPrevious from '../global-buttons/LevelContinueOrPrevious';
import Background_music_1 from "../../../../assets/common/audio/Background_music_1.mp3";

let bgAudio = new Audio(Background_music_1);
let backgroundMusicStatus = Number(localStorage.getItem('backgroundMusicStatus')) || 0;
const Header = ({ onMusicButtonClick, onHomeButtonClick, onHintButtonClick, playHint, score = 0, selectedLevel, percentFill,
  isHintActive, isBackActive, PlayAgainButton, startPlay, setDiplayBgImage, setIsAudioPlaying, playAudio, pauseAudio, currentAudio }) => {
  const [isMusicPlaying, setMusicPlaying] = useState(backgroundMusicStatus);
  const [previousButtonPressed, setPreviousButtonPressed] = useState(false);
  const [gameStart, setGameStart] = useState(false)
  const musicButtonIcon = isMusicPlaying ? Music : Music_Mute;
  const hintButtonIcon = isHintActive ? Hint : Hint_Inactive;

  const pauseAudioAndReset = () => {
    bgAudio.pause();
    bgAudio.currentTime = 0;
  };

  const playAudioLoop = () => {
    setTimeout(()=>{
      bgAudio.play();
      bgAudio.loop = true;
    },1)
  };

  const handleFocus = () => {
    const backgroundMusicStatus = Number(localStorage.getItem('backgroundMusicStatus')) || 0;
    console.log(backgroundMusicStatus, !startPlay)
    if (backgroundMusicStatus) {
      pauseAudioAndReset();
      playAudioLoop();
    }
  }

  const handleVisibilityChangeH = () => {
    if (document.hidden || document.webkitHidden) {
      pauseAudioAndReset();
    } else {
      if (bgAudio) {
        handleFocus();
      }
    }
  };

  useEffect(() => {
    // window.addEventListener('blur', pauseAudioAndReset);
    // window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChangeH);
    document.addEventListener('webkitvisibilitychange', handleVisibilityChangeH);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChangeH);
      document.removeEventListener('webkitvisibilitychange', handleVisibilityChangeH);
    }
  }, [])
 


  useEffect(() => {
    if (!('backgroundMusicStatus' in localStorage)) {
       localStorage.setItem('backgroundMusicStatus', 1) 
       setMusicPlaying(true)
      // localStorage.getItem('backgroundMusicStatus') === 1 &&  localStorage.setItem('backgroundMusicStatus', 1) 
    }
  }, [])

  useEffect(() => {
    let backgroundMusicStatus = Number(localStorage.getItem('backgroundMusicStatus')) || 0;
    console.log(startPlay, backgroundMusicStatus)
    if (!startPlay && backgroundMusicStatus) {
      bgAudio.play()
      bgAudio.loop = true
    } else {
      bgAudio.pause()
      bgAudio.currentTime = 0;

    }
  }, [isMusicPlaying, startPlay])

  return (
    <div className="container-fluid" style={{position: 'relative', zIndex: '11'}} >
      <div style={styles.headerContainer}>
        <div style={styles.headerItems}>
          <button className="btn p-0" type="button" onClick={onHomeButtonClick} data-exclude-click="true">
            <img src={Home} className='home_icon' alt="Home" data-exclude-click="true"/>
          </button>
          <button className="btn p-0 ms-1" type="button" 
            data-exclude-click="true"
            onClick={isBackActive ? () => {
              setPreviousButtonPressed(true)
              setDiplayBgImage(true);
              pauseAudio(currentAudio, setIsAudioPlaying);
            } : () => { }}>
            {
              isBackActive && (
                <img src={Back} className='headbar_icon' alt="Back" data-exclude-click="true"/>
              ) || (
                <img src={Back_Inactive} className='headbar_icon' alt="Back" />
              )
            }

          </button>
        </div>
        <div style={{ flex: 2, marginLeft: '10%', position: 'relative' }}>
          <div className='progressBarContainer' style={{ position: 'absolute', top: -2, left: 1, background: '#FDE888', height: '100%', width: '70%', marginLeft: 20 }}>   </div>
          <ProgessBar selectedLevel={selectedLevel} percentFill={percentFill} />
          <div className='progressBarContainer' style={{ position: 'absolute', bottom: -13, left: 0, background: '#AA6427', height: '100%', width: '70%', marginLeft: 20 }}>

          </div>
        </div>
        <div style={{ ...styles.headerItems, justifyContent: 'flex-end', display: 'flex' }}>
          <button id="music-btn" className="music-btn btn p-0 ms-1" type="button" data-exclude-click="true" onClick={() => {
            let backgroundMusicStatus = Number(localStorage.getItem('backgroundMusicStatus')) || 0;
            if (backgroundMusicStatus) {
              localStorage.setItem('backgroundMusicStatus', 0)
              setMusicPlaying(false)
            } else {
              localStorage.setItem('backgroundMusicStatus', 1)
              setMusicPlaying(true)
            }
          }}>
            <img id="music-icon" src={musicButtonIcon} alt="Music" className="music_icon" data-exclude-click="true"/>
          </button>
          <button className="btn p-0 ms-1 hintButtonHeader" type="button" onClick={onHintButtonClick} disabled={!isHintActive} data-exclude-click="true">
            <img src={hintButtonIcon} alt="Hint" className="hint_icon" data-exclude-click="true"/>
          </button>
          <button className="btn p-0 ms-1" type="button">
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', position: 'relative' }}>
              <span className='score_card'>{localStorage.getItem('rewardPoints') ? Number(localStorage.getItem('rewardPoints')) : 0}</span>
              <img src={Rewards} alt="Rewards" className='rewards_icon' />
            </div>
          </button>
        </div>
      </div>
      {
        previousButtonPressed && (
          <LevelContinueOrPrevious 
          setPreviousButtonPressed={setPreviousButtonPressed} 
          setDiplayBgImage = {setDiplayBgImage} 
          PlayAgainButton={PlayAgainButton}
          setIsAudioPlaying={setIsAudioPlaying}
          playAudio={playAudio}
          pauseAudio={pauseAudio}
          currentAudio={currentAudio}
          PreviousButton={() => {
            let currentLevel = Number(localStorage.getItem('currentLevel') || 0);
            if (currentLevel > 0) {
              currentLevel--;
              localStorage.setItem('currentLevel', currentLevel);
              location.reload()
            }
          }}
          onBackContinue = {(audio)=> {
            playAudio(audio, setIsAudioPlaying)
          }}
          />
        )
      }
    </div>
  );
};

const styles = {
  headerContainer: { display: 'flex', width: '100%', height: 35, paddingTop: 10 },
  headerItems: { flex: 1 }
};

export default Header;
