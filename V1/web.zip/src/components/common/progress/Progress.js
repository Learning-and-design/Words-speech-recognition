import React from 'react';
import './Progress.css';
import { calculatePercentage } from '../../../utils/helper';

const PROGRESS_CONSTANT = [1, 2, 3, 4];

const ProgessBar = ({ selectedLevel = 0, percentFill = 0 }) => {
  let maxLevel = localStorage.getItem('maxLevel') || 0;
  maxLevel = Number(maxLevel);
  let gameCompletedTill = Number(localStorage.getItem('gameCompletedTill')) || 0;
  const percentageValues = [
    calculatePercentage('level1'),
    calculatePercentage('level2'),
    calculatePercentage('level3'),
    calculatePercentage('level4'),
  ];
  

  return (
    <div className='progressBarContainer' style={{ position: 'absolute', zIndex: 1 }}>
      {PROGRESS_CONSTANT.map((item, index) => (
        <div
          className='progressLevel'
          style={item === selectedLevel ? { color: 'black' } : {}}
          key={item}
        >
          <div style={{marginBottom: '-2px'}}>LEVEL {item}</div>
          <div
            className="progress"
            role="progressbar"
            aria-label="Basic example"
            aria-valuenow="100"
            aria-valuemin="0"
            aria-valuemax="100"
            style={
              item === selectedLevel
                ? {
                    width: '80%',
                    height: '2.3vh',
                    border: '1.6px solid black',
                    borderRadius: 4,
                  }
                : {
                    width: '80%',
                    height: '2.3vh',
                    border: '1.6px solid #AA6427',
                    borderRadius: 4,
                  }
            }
          >
            {item <= gameCompletedTill && (
              <div className={`progress-bar progessBarStyle`} style={{ width: '100%' }}></div>
            )}
            <div
              className={`progress-bar progessBarStyle`}
              style={{
                width: `${item === selectedLevel ? percentFill : 0}%`,
              }}
            ></div>
            {!(item <= gameCompletedTill || item === selectedLevel) && <div
              className={`progress-bar progessBarStyle`}
              style={{
                width: `${percentageValues[index]}%`,
              }}
            ></div>}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProgessBar;