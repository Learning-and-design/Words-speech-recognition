import React, { useEffect, useState, useRef } from "react";
import Continue from "../../../../../assets/common/textures/interactions/Continue.png";
import Picknewgame from "../../../../../assets/common/textures/interactions/Picknewgame.png";
import "./HomeContinueOrPicknew.css";
import GL_A_18 from "../../../../../assets/common/audio/GL_A_18.mp3";

const homePalyAgainAudio = new Audio(GL_A_18);
const HomeContinueOrPicknew = ({
  setIsHomeContinueOrPicknew,
  onClose,
  playAudio,
  pauseAudio,
  currentAudio,
  setIsAudioPlaying
}) => {
  const prevAudioRef = useRef(currentAudio);

  useEffect(() => {
    playAudio(homePalyAgainAudio, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  const handleContinueClick = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    setIsHomeContinueOrPicknew(false);
    !(prevAudioRef.current?.src === homePalyAgainAudio.src) && onClose(prevAudioRef.current);
  };

  const handlePickNewGameClick = () => {
    pauseAudio(homePalyAgainAudio, setIsAudioPlaying);
    setIsHomeContinueOrPicknew(false);
    const localData = JSON.parse(localStorage.getItem("postDataSpeech"));
    if (window?.ReactNativeWebView) {
      // const capturedData = JSON.parse(localStorage.getItem("capturedData"));
      window.ReactNativeWebView.postMessage(
        JSON.stringify({ home: 1, gameData: { ...localData } })
      );
    }
  };

  return (
    <div
      style={{
        zIndex: 12,
        position: "fixed",
        top: 0,
        height: "100%",
        width: "100%",
      }}
    >
      <div
        className="play_agian_next_div"
        style={{ display: "flex", gap: "150px" }}
      >
        <div>
          <button
            className="btn p-0"
            type="button"
            onClick={handleContinueClick}
          >
            <img
              src={Continue}
              className="my_play_btn img-fluid"
              alt="Playagain"
            />
          </button>
        </div>
        <div>
          <button
            className="btn"
            type="button"
            onClick={handlePickNewGameClick}
          >
            <img
              src={Picknewgame}
              className="Picknewgame img-fluid"
              alt="Play_the_next_level"
              style={{ position: "relative", left: "15px" }}
            />
          </button>
        </div>
      </div>
    </div>
  );
};

export default HomeContinueOrPicknew;