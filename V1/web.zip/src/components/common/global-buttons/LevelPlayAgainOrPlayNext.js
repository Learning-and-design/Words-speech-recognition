import React, { useEffect, useState } from "react";
import "./common.css";
import Playagain from "../../../../assets/common/textures/interactions/Playagain.png";
import Playgame from "../../../../assets/common/textures/interactions/Playgame.png";
import Play_the_next_level from "../../../../assets/common/textures/interactions/Play_the_next_level.png";
import { playNextLevel } from "../../../utils/helper";
import GL_A_5 from "../../../../assets/common/audio/GL_A_5.mp3";

const playAgainAudio = new Audio(GL_A_5);
const LevelPlayAgainOrPlayNext = ({
  PlayAgainButton,
  setCurrentLevelState,
  level,
  setIsAudioPlaying,
  playAudio,
  pauseAudio,
  currentAudio,
}) => {

  useEffect(() => {
    playAudio(playAgainAudio, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  const handlePlayAgainButtonClick = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    PlayAgainButton();
  };

  const handlePlayNextLevelButtonClick = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    console.log(level);
    playNextLevel(setCurrentLevelState, level);
    setCurrentLevelState(level + 1);
    window.location.reload();
  };

  return (
    <>
      <div
        className="play_agian_next_div"
        style={{ display: "flex", gap: "150px", zIndex: "11"}}
      >
        <div>
          <button
            className='btn p-0'
            type="button"
            onClick={handlePlayAgainButtonClick}
          >
            <img
              src={Playagain}
              className="my_play_btn img-fluid"
              alt="Playagain"
            />
          </button>
        </div>
        <div>
          <button
            className='btn'
            type="button"
            onClick={handlePlayNextLevelButtonClick}
          >
            <img
              src={Play_the_next_level}
              className="Play_the_next_level img-fluid"
              alt="Play_the_next_level"
              style={{ position: "relative", left: "15px" }}
            />
          </button>
        </div>
      </div>
    </>
  );
};

export default LevelPlayAgainOrPlayNext;
