{/* <div className="play_agian_next_div" style={{ display: 'flex', gap: '150px'}}>
<div >
  <button
    className="btn p-0"
    type="button"
    onClick={() => {
        pauseContextAudio(currentAudio);
        setSoundFilesEnded(false);
        resetLevelData();
        PlayButton();
        setShowReplaySkip(true);
        setIsButtonDisabled(true);
      // }
    }}
  >
    <img
      src={Playagain}
      className="my_play_btn img-fluid"
      alt="Playagain"
    />
  </button>
</div>
<div >
  <button
    className="btn"
    type="button"
    onClick={() => {
      // if (!isGameButtonDisabled) {
        pauseContextAudio(currentAudio);
        playNextLevel(setCurrentLevelState, 0);
        setCurrentLevelState(1)
        window.location.reload()
      // }
    }}
  >
    <img src={Playgame} className="my_play_btn img-fluid" alt="Playgame" style={{position: 'relative', left: '15px'}}/>
  </button>
</div>
</div> */}