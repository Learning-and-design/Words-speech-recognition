import React, { useEffect, useState, useRef } from "react";
import "./common.css";
import Continue from "../../../../assets/common/textures/interactions/Continue.png";
import PlayNextLevel from "../../../../assets/common/textures/interactions/Play_the_next_level.png";
import Play_the_next_level from "../../../../assets/common/textures/interactions/Play_the_next_level.png";
import { playNextLevel } from "../../../utils/helper";
import GL_A_17 from "../../../../assets/common/audio/GL_A_17.mp3";

const skipLevelAudio = new Audio(GL_A_17);
const SkipLevelContinueOrPlayNext = ({
  setCurrentLevelState,
  level,
  setShowReplaySkip,
  setShowReplayLevelSkip,
  setIsAudioPlaying,
  setDiplayBgImage,
  onContinueAfterLevelComplete,
  playAudio,
  pauseAudio,
  currentAudio,
}) => {
  const prevSkipLevelAudioRef = useRef(currentAudio);

  useEffect(() => {
    playAudio(skipLevelAudio, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  const handlePlayAgainButtonClick = () => {
    pauseAudio(skipLevelAudio, setIsAudioPlaying);
    setShowReplaySkip(true);
    setShowReplayLevelSkip(false);
    onContinueAfterLevelComplete(prevSkipLevelAudioRef.current);
    setDiplayBgImage(false);
  };

  const handlePlayNextLevelButtonClick = () => {
    pauseAudio(skipLevelAudio, setIsAudioPlaying);
    setDiplayBgImage(false);
    playNextLevel(setCurrentLevelState, level);
    setCurrentLevelState(level + 1);
    window.location.reload();
  };
  return (
    <>
      <div
        className="play_agian_next_div"
        style={{ display: "flex", gap: "150px", zIndex: "11"}}
      >
        <div>
          <button
            className={'btn p-0'}
            type="button"
            onClick={handlePlayAgainButtonClick}
          >
            <img src={Continue} className="hint_continue" alt="Continue" />
          </button>
        </div>
        <div>
          <button
            className={'btn'}
            type="button"
            onClick={handlePlayNextLevelButtonClick}
          >
            <img
              src={Play_the_next_level}
              className="Play_the_next_level"
              alt="Next"
              style={{ position: "relative", left: "15px" }}
            />
          </button>
        </div>
      </div>
    </>
  );
};

export default SkipLevelContinueOrPlayNext;
