import React, { useEffect, useRef } from "react";
import "./common.css";
import PreviousLevelImage from "../../../../assets/common/textures/interactions/Previouslevel.png";
import Continue from "../../../../assets/common/textures/interactions/Continue.png";
import Playagain from "../../../../assets/common/textures/interactions/Playagain.png";
import { playNextLevel } from "../../../utils/helper";
import GL_A_2 from "../../../../assets/common/audio/GL_A_2.mp3";

const previousLevelAudio = new Audio(GL_A_2);
const LevelContinueOrPrevious = ({
  PreviousButton,
  setPreviousButtonPressed,
  setIsAudioPlaying,
  setDiplayBgImage,
  playAudio,
  pauseAudio,
  currentAudio,
  onBackContinue,
}) => {
  const previousLevelAudioRef = useRef(currentAudio);
  useEffect(() => {
    playAudio(previousLevelAudio, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  const handleContinueClick = () => {
    pauseAudio(previousLevelAudio, setIsAudioPlaying);
    setPreviousButtonPressed(false);
    setDiplayBgImage(false);
    playAudio(null);
    onBackContinue(previousLevelAudioRef.current);
  };

  return (
    <>
      <div
        className="play_agian_next_div"
        style={{ height: "100vh", display: "flex", gap: "150px" }}
      >
        <div>
          <button
            className="btn"
            type="button"
            onClick={() => handleContinueClick()}
          >
            <img src={Continue} style={{ width: 72, height: "auto" }} />
          </button>
        </div>
        <div>
          <button
            className="btn p-0"
            type="button"
            onClick={() => {
              pauseAudio(previousLevelAudio, setIsAudioPlaying);
              PreviousButton();
            }}
          >
            <img
              src={PreviousLevelImage}
              style={{
                width: 96,
                height: "auto",
                position: "relative",
                left: "15px",
              }}
            />
          </button>
        </div>
      </div>
    </>
  );
};

export default LevelContinueOrPrevious;
