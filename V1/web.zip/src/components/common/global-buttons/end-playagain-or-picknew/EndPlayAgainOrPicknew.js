import React, { useEffect, useState } from "react";
import "./EndPlayAgainOrPicknew.css";
import Playagain from "../../../../../assets/common/textures/interactions/Playagain.png";
import Playgame from "../../../../../assets/common/textures/interactions/Playgame.png";
import Play_the_next_level from "../../../../../assets/common/textures/interactions/Play_the_next_level.png";
import Picknewgame from "../../../../../assets/common/textures/interactions/Picknewgame.png";
import GL_A_6 from "../../../../../assets/common/audio/GL_A_6.mp3";
const endlastLevel = new Audio(GL_A_6);

const EndPlayAgainOrPicknew = ({
  PlayAgainButton,
  setCurrentLevelState,
  setIsAudioPlaying,
  playAudio,
  pauseAudio,
  currentAudio,
  setDiplayBgImage
}) => {
  useEffect(() => {
    playAudio(endlastLevel, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  return (
    <>
      <div
        className="play_agian_next_div"
        style={{ display: "flex", gap: "150px", zIndex: "11" }}
      >
        <div>
          <button
            className="btn p-0"
            type="button"
            onClick={() => {
              pauseAudio(currentAudio, setIsAudioPlaying);
              PlayAgainButton();
              setDiplayBgImage(false);
            }}
          >
            <img
              src={Playagain}
              className="my_play_btn img-fluid"
              alt="Playagain"
            />
          </button>
        </div>
        <div>
          <button
            className="btn"
            type="button"
            onClick={async () => {
              pauseAudio(currentAudio, setIsAudioPlaying);
              const localData = JSON.parse(localStorage.getItem("postDataSpeech"));
              if (window?.ReactNativeWebView) {
                // const capturedData = JSON.parse(
                //   localStorage.getItem("capturedData")
                // );
                window.ReactNativeWebView.postMessage(
                  JSON.stringify({
                    home: 1,
                    gameData: { ...localData },
                  })
                );
                localStorage.clear();
                await localStorage.setItem("currentLevel", 1);
                setCurrentLevelState(1);
              }
            }}
          >
            <img
              src={Picknewgame}
              className="Picknewgame img-fluid"
              alt="Play_the_next_level"
              style={{ position: "relative", left: "15px" }}
            />
          </button>
        </div>
      </div>
    </>
  );
};

export default EndPlayAgainOrPicknew;
