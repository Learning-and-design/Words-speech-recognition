import React, { useEffect, useRef } from "react";
import Continue from "../../../../assets/common/textures/interactions/Continue.png";
import Exit from "../../../../assets/common/textures/interactions/Exit.png";
import ContinueOrLeave from "../../.././../assets/common/audio/GL_A_9.mp3";
import "./common.css";

const hintSkipAudio = new Audio(ContinueOrLeave);
const HintSkipContinueOrExit = ({
  setIsAudioPlaying,
  setStartset,
  setShowHintSkip,
  setShowMascot,
  setShowGrid,
  setShowSecondMascot,
  setShowSkipButton,
  setIsHintActive,
  onContinue,
  setDiplayBgImage,
  onExit,
  playAudio,
  pauseAudio,
  currentAudio,
}) => {
  const hintSkipAudioRef = useRef(currentAudio);
  // useEffect(() => {
  //   pauseAudio(currentAudio, setIsAudioPlaying);
  //   debugger
  // },[])

  useEffect(() => {
    playAudio(hintSkipAudio, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  const handleContinuePresentation = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    onContinue(hintSkipAudioRef.current);
    setShowHintSkip(false);
    setDiplayBgImage(false);
  };

  const handleResumePlay = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    setStartset(true);
    setShowMascot(false);
    setShowGrid(false);
    setShowSecondMascot(false);
    setShowSkipButton(false);
    setIsHintActive(true);
    setShowHintSkip(false);
    setDiplayBgImage(false);
    onExit();
  };

  return (
    <>
      <div
        className="play_agian_next_div"
        style={{ display: "flex", gap: "165px",zIndex: "11" }}
      >
        <div>
          <button
            className={'btn p-0'}
            type="button"
            onClick={handleContinuePresentation}
          >
            <img src={Continue} className="hint_continue" alt="Continue" />
          </button>
        </div>
        <div>
          <button
            className={'btn'}
            type="button"
            onClick={handleResumePlay}
          >
            <img src={Exit} className="exit_image" alt="Exit" />
          </button>
        </div>
      </div>
    </>
  );
};

export default HintSkipContinueOrExit;
