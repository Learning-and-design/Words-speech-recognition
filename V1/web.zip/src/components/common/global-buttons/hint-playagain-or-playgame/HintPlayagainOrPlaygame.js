import React, { useEffect, useRef } from "react";
import Playagain from "../../../../../assets/common/textures/interactions/Playagain.png";
import Playgame from "../../../../../assets/common/textures/interactions/Playgame.png";
import "./HintPlayagainOrPlaygame.css";
import GL_A_8 from "../../../../../assets/common/audio/GL_A_8.mp3";

const hintPlayAgainAudio = new Audio(GL_A_8);

const HintPlayagainOrPlaygame = ({
  setShowHintPlayAgain,
  setStartset,
  setIsAudioPlaying,
  handleHintButtonClick,
  setShowSkipButton,
  onPlayTheGame,
  setDiplayBgImage,
  playAudio,
  pauseAudio,
  currentAudio,
}) => {
  const hintHintPlayAgain = useRef(currentAudio);

  useEffect(() => {
    playAudio(hintPlayAgainAudio, setIsAudioPlaying);
  }, [playAudio, pauseAudio]);

  const handleReplayHint = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    handleHintButtonClick();
    setShowHintPlayAgain(false);
    setShowSkipButton(true);
    setDiplayBgImage(false); 
  };

  const handleHintClick = () => {
    pauseAudio(currentAudio, setIsAudioPlaying);
    setShowHintPlayAgain(false);
    setStartset(true);
    setShowSkipButton(false);
    setDiplayBgImage(false);
    onPlayTheGame();

    //   }
  };
  return (
    <>
      <div
        className="play_agian_next_div"
        style={{ display: "flex", gap: "150px" }}
      >
        <div>
          <button className="btn p-0" type="button" onClick={handleReplayHint}>
            <img
              src={Playagain}
              className="my_play_btn img-fluid"
              alt="Playagain"
            />
          </button>
        </div>
        <div>
          <button className="btn" type="button" onClick={handleHintClick}>
            <img
              src={Playgame}
              className="Hint_Play_Again img-fluid"
              alt="Play_the_next_level"
              style={{ position: "relative", left: "15px" }}
            />
          </button>
        </div>
      </div>
    </>
  );
};

export default HintPlayagainOrPlaygame;
