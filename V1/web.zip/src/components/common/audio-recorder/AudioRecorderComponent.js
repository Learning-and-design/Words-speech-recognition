import React, { useState, useRef, useEffect } from "react";
import AudioRecorder from "audio-recorder-polyfill";
window.MediaRecorder = AudioRecorder;
import { speechApi } from "../../../utils/apiService";
import mic_button from "../../../../assets/level-0/images/mic_button.png";
import "./AudioRecorderComponent.css";
import { audio } from "../../../constants/common";

const AudioRecorderComponent = ({
  referenceText,
  onStartRecording,
  onStopRecording,
  wrongAnswer,
  setIsRecording,
  isRecording,
  level,
}) => {
  const [recorder, setRecorder] = useState(null);
  const audioRef = useRef(null);
  const isToched = useRef(false);
  const audioChunks = useRef([]);
  const [audioProcessing, setAudioProcessing] =  useState(false)

  const convertBase64ToWav = (base64Data) => {
    const binaryData = atob(base64Data);
    const arrayBuffer = new ArrayBuffer(binaryData.length);
    const view = new Uint8Array(arrayBuffer);
    for (let i = 0; i < binaryData.length; i++) {
      view[i] = binaryData.charCodeAt(i);
    }
    const blob = new Blob([arrayBuffer], { type: "audio/wav" });
    return blob;
  };

  const handleErrorResponse = async(errorMessage) => {
    const element = document.getElementById("micImage");
    audioChunks.current = [];
    await element.classList.add("rise_shake");
    setTimeout(() => {
      element.classList.remove("rise_shake");
      setAudioProcessing(false);
      setIsRecording(false);
    }, 2000);
    // alert(errorMessage);
    if(typeof errorMessage == 'string' && window?.ReactNativeWebView){
      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          error: errorMessage,
        })
      );
    }
  };

  
  const startRecording = async () => {
    if (isRecording) return;
    setIsRecording(true);

    const element = document.getElementById("micImage");
    if (recorder) {
      if (recorder.state === "recording") {
        return; // Recording is already in progress
      }
    }

    try {
      const getUserMedia =
        (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) ||
        navigator.getUserMedia ||
        navigator.webkitGetUserMedia ||
        navigator.mozGetUserMedia;
      if (getUserMedia) {
        // Constraints for accessing the user's microphone
        const constraints = { audio: true };

        // Request access to the microphone
        const stream = await (navigator.mediaDevices.getUserMedia
          ? navigator.mediaDevices.getUserMedia(constraints)
          :  getUserMedia.call(navigator, constraints));

        audioChunks.current = [];
        const newRecorder = new MediaRecorder(stream);
        setRecorder(newRecorder);
        newRecorder.addEventListener("dataavailable", (e) => {
          if (e.data.size > 0) {
            audioChunks.current.push(e.data);
          }
        });

        newRecorder.addEventListener("stop", () => {
          setAudioProcessing(true);
          const audioBlob = new Blob(audioChunks.current, { type: "audio/wav" });
          audioRef.current.src = URL.createObjectURL(audioBlob);
          const result = speechApi(audioBlob, referenceText);
          result
            .then((res) => {
              if (
                !(
                  res?.success == true &&
                  res?.data?.evaluatedText?.replace(/\./g, "")?.toLowerCase() ==
                    referenceText
                )
              ) {
                handleErrorResponse("API response indicates an error.");
              }else{
                setAudioProcessing(false);
              }
              audioChunks.current = [];
            })
            .catch((error) => {
              error?.message && handleErrorResponse(error.message);
            });
            onStopRecording(result, referenceText);
        });

        newRecorder.start();
      } else {
        handleErrorResponse("getUserMedia is not supported in this browser.")
      }
    } catch (error) {
      handleErrorResponse("Error starting recording: " + error)
    }
  };
  
  const stopRecording = () => {
    if (recorder && recorder.state === "recording") {
      recorder.stop();
    }
  }

  return (
    <>
      <audio ref={audioRef} controls style={{ display: "none" }}></audio>
      <img
        id="micImage"
        onClick={!isRecording ? startRecording : !audioProcessing ? stopRecording : ()=>{console.log('boom')}}
        src={mic_button}
        alt="mic button"
        style={level != 2 ? { height: "33%" } : {}}
        className={isRecording && !audioProcessing ? "recording-gesture" : audioProcessing ? "disable-mic" : ""}
      />
    </>
  );
};

export default AudioRecorderComponent;
