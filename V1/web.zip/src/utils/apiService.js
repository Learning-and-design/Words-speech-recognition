export const speechApi = async (audioFile, referenceText) => {
  const formData = new FormData();
  // formData.append("audioFile", audioFile);
  formData.append("reference_text", referenceText);
  formData.append('audioFile', audioFile);

  try {
    const response = await fetch("http://13.233.134.140/api/speech/speech/score-audio-file", {
      method: "POST",
      body: formData,
    });

    if (response.status === 200) {
      const data = await response.json();
      return data;
    } else if (response.status === 400) {
      const errorData = await response.json();
      throw new Error("API error: " + JSON.stringify(errorData));
    } else {
      alert("Unknown error occurred");
      throw new Error("Unknown error occurred.");
    }
  } catch (error) {
   throw new Error("Network error: " + error);
  }
};
