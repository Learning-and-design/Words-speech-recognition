export const shuffleArray = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}


export const playNextLevel = (setCurrentLevelState, level) => {
    let maxLevel = Number((localStorage.getItem('maxLevel') || 0));
    if (level === maxLevel) {
        maxLevel++;
        localStorage.setItem('maxLevel', maxLevel);
        localStorage.setItem('currentLevel', (level + 1));

    } else {
        localStorage.setItem('currentLevel', (level + 1));
    }
}

export const calculatePercentage = (level) => {
    let set  = JSON.parse(localStorage.getItem('currentSet'));
    if(set){
        let currentSet = Number(set[level]);
        if(level !== 'level4'){
            if (currentSet === 0) {
                return 0;
              }
              if (currentSet % 2 !== 0) {
                  currentSet--; // Reduce it to the previous even number 
              }
            const percentage = (currentSet / 10) * 100;
            return percentage;
            
        }else if(level === 'level4'){
            if (currentSet === 10) {
                return 100;
              } else if (currentSet === 8) {
                return 60;
              } else if (currentSet === 4) {
                console.log('coreeeeeeeeeeee')
                return 30;
              } else if(currentSet < 4){
                return 0;
              }else if(currentSet < 8){
                return 30;
              }else if(currentSet < 10){
                return 60;
              }
        }
    }
   
}


export const calculateTimeSpent = (startTime=0, endTime=0) => {
  const timeSpentInMilliseconds = endTime - startTime;
  const timeSpentInSeconds = Math.floor(timeSpentInMilliseconds / 1000);
  return timeSpentInSeconds;
}
