import "./App.css";
import React, { useState, useEffect } from "react";
import ".././node_modules/bootstrap/dist/css/bootstrap.min.css";
import ".././node_modules/bootstrap/dist/js/bootstrap.bundle";
import Level0 from "./components/Level0";
import Level2 from "./components/Level2";
// import Level1 from "./Level1";
import { appData, setData } from "./constants/common";
import { AudioManagerProvider } from "./AudioManagerContext";

const loadLevel = (
  currentLevelState,
  setCurrentLevelState,
  updatePostData,
  updateSetData
) => {
  const currentLevel = localStorage.getItem("currentLevel") || 0;
  const maxLevel = localStorage.getItem("maxLevel") || 0;

  const enableSkip = currentLevel < maxLevel;
  const commonProps = {
    setCurrentLevelState,
    enableSkip,
    updatePostData,
    updateSetData,
  };

  switch (Number(currentLevelState)) {
    case 2:
      return <Level2 {...commonProps} />;
    default:
      return <Level0 {...commonProps} />;
  }
};

function App() {
  const [currentLevelState, setCurrentLevelState] = useState(0);
  const [postData, setPostData] = useState(() => {
    const savedData = localStorage.getItem("postDataSpeech");
    return savedData ? JSON.parse(savedData) : appData;
  });

  const [allLevelSetData, setAllLevelSetData] = useState(() => {
    const temp = localStorage.getItem("currentSet");
    return temp ? JSON.parse(temp) : setData;
  });

  useEffect(() => {
    const handleMessage = async (event) => {
      const recievedData = event?.data;
      const isFirstLoad = localStorage.getItem('firstLoadSpeech') === null;
      console.log('isFirstLoad', isFirstLoad)
      if (recievedData && isFirstLoad) {
        if (typeof recievedData.levelDetails === "string") {
          let levelDetails = JSON.parse(recievedData.levelDetails);
          let tempRecievedData = { ...recievedData, ...{levelDetails: levelDetails} }; 
          let afterResetLeveldetails = await resetAllTimespent(tempRecievedData);
          setPostData(afterResetLeveldetails);
        } else {
          let afterResetLeveldetails = await resetAllTimespent(recievedData);
          setPostData(afterResetLeveldetails);
        }
        if (recievedData?.completed == 1) {
          localStorage.setItem("gameCompletedTill", 4);
          localStorage.setItem("rewardPoints", 40);
          localStorage.setItem("presentationCompletedTill", 4);
          localStorage.setItem("maxLevel", 4);
        }
        if (recievedData?.totalRewards) {
          localStorage.setItem("rewardPoints", recievedData?.totalRewards);
        }
        localStorage.setItem('firstLoadSpeech', 'false');
      }
    };
    // handleMessage();
    document.addEventListener('message', handleMessage);
    return () => {
      document.removeEventListener('message', handleMessage);
    }
  }, []);

  useEffect(() => {
    const currentLevel = localStorage.getItem("currentLevel") || 0;
    setCurrentLevelState(currentLevel);
  }, []);

  useEffect(() => {
    localStorage.setItem("postDataSpeech", JSON.stringify(postData));
  }, [postData]);

  useEffect(() => {
    localStorage.setItem("currentSet", JSON.stringify(allLevelSetData));
  }, [allLevelSetData]);

  const updateSetData = (key, value) => {
    setAllLevelSetData((prevState) => ({
      ...prevState,
      [key]: value,
    }));
  };

  const updatePostData = (whatToUpdate, data) => {
    const { level, time = 0 } = { ...data };
    switch (whatToUpdate) {
      case "presenationStart":
        setLevelStarted(level, time);
        break;

      case "presenationEnd":
        setPresentationCompleted(level, time);
        break;

      case "setStart":
        setPlaycount(level, time);
        break;

      case "setEnd":
        setLevelCompleted(level, time);
        break;

      case "right":
        setCorrectAttempts(level, time);
        break;

      case "wrong":
        setWrongAttempts(level, time);
        break;

      case "levelPresentationComplete":
        setLevelPresenationCompleted(level, time);
        break;

      case "addTimespentWhenJumpedOut":
        addTimespentWhenJumpedOut(level, time);
        break;

      case "addTimespentWhenJumpedOutPresentation":
        addTimespentWhenJumpedOutPresentation(level, time);
    }
  };

  const resetAllTimespent = (data) => {
    data.levelDetails.level0.presentation.timeSpent = 0;
    data.levelDetails.level1.presentation.timeSpent = 0;
    data.levelDetails.level2.presentation.timeSpent = 0;
    data.levelDetails.level3.presentation.timeSpent = 0;
    data.levelDetails.level4.presentation.timeSpent = 0;
    data.levelDetails.level1.timeSpent = 0;
    data.levelDetails.level2.timeSpent = 0;
    data.levelDetails.level3.timeSpent = 0;
    data.levelDetails.level4.timeSpent = 0;
    return data;
  };


  // call when level presentation play started...........
  const setLevelStarted = (levelNum, timeSpent) => {
    if (postData == null) return;
    const updatedData = { ...postData };
    switch (levelNum) {
      case 1:
        updatedData.levelDetails.level1.presentation.playCount += 1;
        break;

      case 2:
        updatedData.levelDetails.level2.presentation.playCount += 1;
        break;

      case 3:
        updatedData.levelDetails.level3.presentation.playCount += 1;
        break;

      case 4:
        updatedData.levelDetails.level4.presentation.playCount += 1;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  // when presenation completed
  const setPresentationCompleted = (levelNum, timeSpent) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 1:
        updatedData.levelDetails.level1.presentation.completedCount += 1;
        updatedData.levelDetails.level1.presentation.completed = 1;
        updatedData.levelDetails.level1.presentation.timeSpent =
          parseInt(updatedData.levelDetails.level1.presentation.timeSpent) +
          timeSpent;
        break;
      case 2:
        updatedData.levelDetails.level2.presentation.completedCount += 1;
        updatedData.levelDetails.level2.presentation.completed = 1;
        updatedData.levelDetails.level2.presentation.timeSpent =
          parseInt(updatedData.levelDetails.level2.presentation.timeSpent) +
          timeSpent;
        break;
      case 3:
        updatedData.levelDetails.level3.presentation.completedCount += 1;
        updatedData.levelDetails.level3.presentation.completed = 1;
        updatedData.levelDetails.level3.presentation.timeSpent =
          parseInt(updatedData.levelDetails.level3.presentation.timeSpent) +
          timeSpent;
        break;
      case 4:
        updatedData.levelDetails.level4.presentation.completedCount += 1;
        updatedData.levelDetails.level4.presentation.completed = 1;
        updatedData.levelDetails.level4.presentation.timeSpent =
          parseInt(updatedData.levelDetails.level4.presentation.timeSpent) +
          timeSpent;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  // call when level set play started...........
  const setPlaycount = (levelNum, timeSpent = 0) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 0:
        updatedData.levelDetails.level0.presentation.playCount += 1;
        break;
      case 1:
        updatedData.levelDetails.level1.playCount += 1;
        break;

      case 2:
        updatedData.levelDetails.level2.playCount += 1;
        break;

      case 3:
        updatedData.levelDetails.level3.playCount += 1;
        break;

      case 4:
        updatedData.levelDetails.level4.playCount += 1;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  // call when level completed...
  const setLevelCompleted = (levelNum, timeSpent, award = false) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 0:
        if (levelNum == updatedData.levelDetails.currentLevel.level) {
          updatedData.levelDetails.currentLevel.level = 1;
          if (updatedData.levelDetails.level1.presentation.completed == 0)
            updatedData.levelDetails.currentLevel.presentationCompleted = 0;
        }
        updatedData.levelDetails.level0.presentation.completed = 1;
        updatedData.levelDetails.level0.presentation.completedCount += 1;
        updatedData.levelDetails.level0.presentation.timeSpent += timeSpent;
        break;

      case 1:
        if (levelNum == updatedData.levelDetails.currentLevel.level) {
          updatedData.levelDetails.currentLevel.level = 2;
          if (updatedData.levelDetails.level2.presentation.completed == 0)
            updatedData.levelDetails.currentLevel.presentationCompleted = 0;
        }
        updatedData.levelDetails.level1.completedCount += 1;
        updatedData.levelDetails.level1.completed = 1;
        updatedData.levelDetails.level1.timeSpent += timeSpent;
        break;

      case 2:
        if (levelNum == updatedData.levelDetails.currentLevel.level) {
          updatedData.levelDetails.currentLevel.level = 3;
          if (updatedData.levelDetails.level3.presentation.completed == 0)
            updatedData.levelDetails.currentLevel.presentationCompleted = 0;
        }
        updatedData.levelDetails.level2.completedCount += 1;
        updatedData.levelDetails.level2.completed = 1;
        updatedData.levelDetails.level2.timeSpent += timeSpent;
        break;

      case 3:
        if (levelNum == updatedData.levelDetails.currentLevel.level) {
          updatedData.levelDetails.currentLevel.level = 4;
          if (updatedData.levelDetails.level4.presentation.completed == 0)
            updatedData.levelDetails.currentLevel.presentationCompleted = 0;
        }
        updatedData.levelDetails.level3.completedCount += 1;
        updatedData.levelDetails.level3.completed = 1;
        updatedData.levelDetails.level3.timeSpent += timeSpent;
        break;

      case 4:
        if (levelNum == updatedData.levelDetails.currentLevel.level) {
          updatedData.levelDetails.currentLevel.level = 1;
        }
        updatedData.levelDetails.level4.completedCount += 1;
        updatedData.levelDetails.level4.completed = 1;
        updatedData.levelDetails.level4.timeSpent += timeSpent;
        updatedData.completed = 1;
        updatedData.isGameCompleted = "completed";
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  const setCorrectAttempts = (levelNum, timeSpent = 0) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 1:
        updatedData.levelDetails.level1.correctAttempts += 1;
        break;
      case 2:
        updatedData.levelDetails.level2.correctAttempts += 1;
        break;
      case 3:
        updatedData.levelDetails.level3.correctAttempts += 1;
        break;
      case 4:
        updatedData.levelDetails.level4.correctAttempts += 1;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  const setWrongAttempts = (levelNum, timeSpent = 0) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 1:
        updatedData.levelDetails.level1.incorrectAttempts += 1;
        break;
      case 2:
        updatedData.levelDetails.level2.incorrectAttempts += 1;
        break;
      case 3:
        updatedData.levelDetails.level3.incorrectAttempts += 1;
        break;
      case 4:
        updatedData.levelDetails.level4.incorrectAttempts += 1;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  const addTimespentWhenJumpedOut = (levelNum, timeSpent) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 0:
        updatedData.levelDetails.level0.presentation.timeSpent += timeSpent;
        break;
      case 1:
        updatedData.levelDetails.level1.timeSpent += timeSpent;
        break;
      case 2:
        updatedData.levelDetails.level2.timeSpent += timeSpent;
        break;
      case 3:
        updatedData.levelDetails.level3.timeSpent += timeSpent;
        break;
      case 4:
        updatedData.levelDetails.level4.timeSpent += timeSpent;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  const addTimespentWhenJumpedOutPresentation = (levelNum, timeSpent) => {
    const updatedData = { ...postData };
    switch (levelNum) {
      case 1:
        updatedData.levelDetails.level1.presentation.timeSpent += timeSpent;
        break;
      case 2:
        updatedData.levelDetails.level2.presentation.timeSpent += timeSpent;
        break;
      case 3:
        updatedData.levelDetails.level3.presentation.timeSpent += timeSpent;
        break;
      case 4:
        updatedData.levelDetails.level4.presentation.timeSpent += timeSpent;
        break;
    }
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  const setLevelPresenationCompleted = (levelNum, timeSpent = 0) => {
    const updatedData = { ...postData };
    if (levelNum == updatedData.levelDetails.currentLevel.level)
      updatedData.levelDetails.currentLevel.presentationCompleted = 1;
    setPostData(updatedData);
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(JSON.stringify({ ...updatedData }));
    }
  };

  return (
    <AudioManagerProvider>
      <div className="App">
        {loadLevel(
          currentLevelState,
          setCurrentLevelState,
          updatePostData,
          updateSetData
        )}
      </div>
    </AudioManagerProvider>
  );
}

export default App;
