import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
} from "react";

const AudioManagerContext = createContext();

export const useAudioManager = () => {
  return useContext(AudioManagerContext);
};

export const AudioManagerProvider = ({ children }) => {
  const [currentAudio, setCurrentAudio] = useState(null);
  const playOrStopWhenScreenInactive = useRef(true);
  var lastActivityTime = useRef(Date.now());
  const playContextAudio = (audio, setIsAudioPlaying) => {
    if (audio) {
      audio.play();
      setIsAudioPlaying(true);
    }
    setCurrentAudio(audio);
  };

  const pauseContextAudio = (audio, setIsAudioPlaying) => {
    if (audio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      setIsAudioPlaying(false);
    }
    setCurrentAudio(audio);
  };

  useEffect(() => {
    const handleVisibilityChange = () => {
      if ((document.hidden || document.webkitHidden) && currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
      } else {
        if (currentAudio) {
          currentAudio && currentAudio.play();
        }
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    document.addEventListener("webkitvisibilitychange", handleVisibilityChange);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      document.removeEventListener(
        "webkitvisibilitychange",
        handleVisibilityChange
      );
    };
  }, [currentAudio]);

  const setF = () => {
    playOrStopWhenScreenInactive.current = false;
  };
  const setT = () => {
    playOrStopWhenScreenInactive.current = true;
  };

  function updateUserActivity() {
    lastActivityTime.current = Date.now();
  }

  const isUserActive = () => {
    const currentTime = Date.now();
    const timeSinceLastActivity = currentTime - lastActivityTime.current;
    const fifteenSeconds = 15000; // 15 seconds in milliseconds
    if (playOrStopWhenScreenInactive.current == true) {
      return timeSinceLastActivity <= fifteenSeconds;
    } else {
      return true;
    }
  };

  useEffect(() => {
    window.addEventListener("focus", setT);
    window.addEventListener("blur", setF);
    window.addEventListener("mousedown", updateUserActivity);
    window.addEventListener("keydown", updateUserActivity);
    window.addEventListener("touchstart", updateUserActivity);
    window.addEventListener("touchmove", updateUserActivity);
    return () => {
      window.removeEventListener("focus", setT);
      window.removeEventListener("blur", setF);
      window.removeEventListener("mousedown", updateUserActivity);
      window.removeEventListener("keydown", updateUserActivity);
      window.removeEventListener("touchstart", updateUserActivity);
      window.removeEventListener("touchmove", updateUserActivity);
    };
  }, []);

  const contextValue = {
    currentAudio,
    playContextAudio,
    pauseContextAudio,
    playOrStopWhenScreenInactive,
    isUserActive,
  };

  return (
    <AudioManagerContext.Provider value={contextValue}>
      {children}
    </AudioManagerContext.Provider>
  );
};
