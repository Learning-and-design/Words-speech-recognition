// LEVEL1 DEMO JSON

export const level1DemoData = [
    {
        id: 1,
        big_img: require('../assets/air_water_level_1/images/Images/glider_level_1.png'),
    },
    {
        id: 2,
        big_img: require('../assets/air_water_level_1/images/Images/helicopter_level_1.png'),
    },
    {
        id: 3,
        big_img: require('../assets/air_water_level_1/images/Images/coracle_level_1.png'),
    },
    {
        id: 4,
        big_img: require('../assets/air_water_level_1/images/Images/ship_level_1.png'),
        sound: require('../assets/air_water_level_0/audio/VBWA_A_L0_7.mp3'),
        wrong_sound: require('../assets/common/audio/For_the_wrong_answer.mp3'),
        correct_sound: require('../assets/common/audio/For_correct_answer.mp3'),
        green_tick: require('../assets/common/textures/interactions/Tick.png'),
        hand_cursor: require('../assets/common/textures/interactions/Hand_Cursor3.png'),
    },
]

// LEVEL1 GAME JSON

export const level1Data = [
    [
        {
            "id": 1,
            "big_img": require('../assets/air_water_level_1/images/Images/rowboat_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_5.mp3'),
            "isCorrect": false
        },
        {
            "id": 2,
            "big_img": require('../assets/air_water_level_1/images/Images/coracle_level_1.png'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_9.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_5.mp3'),
            "isCorrect": true
        },
        {
            "id": 3,
            "big_img": require('../assets/air_water_level_1/images/Images/airplane_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_5.mp3'),
            "isCorrect": false
        },
        {
            "id": 4,
            "big_img": require('../assets/air_water_level_1/images/Images/helicopter_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_5.mp3'),
            "isCorrect": false
        },
    ],
   // this is Set 2
    [
        {
            "id": 5,
            "big_img": require('../assets/air_water_level_1/images/Images/sailboat_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_6.mp3'),
            "isCorrect": false
        },
        {
            "id": 6,
            "big_img": require('../assets/air_water_level_1/images/Images/ship_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_6.mp3'),
            "isCorrect": false
        },
        {
            "id": 7,
            "big_img": require('../assets/air_water_level_1/images/Images/business jet_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_6.mp3'),
            "isCorrect": false
        },
        {
            "id": 8,
            "big_img": require('../assets/air_water_level_1/images/Images/yacht_level_1.png'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_4.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_6.mp3'),
            "isCorrect": true
        },
    ],
    // this is Set 3
    [
        {
            "id": 9,
            "big_img": require('../assets/air_water_level_1/images/Images/helicopter_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_7.mp3'),
            "isCorrect": false
        },
        {
            "id": 10,
            "big_img": require('../assets/air_water_level_1/images/Images/hovercraft_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_5.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_7.mp3'),
            "isCorrect": true
        },
        {
            "id": 11,
            "big_img": require('../assets/air_water_level_1/images/Images/glider_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_7.mp3'),
            "isCorrect": false
        },
        {
            "id": 12,
            "big_img": require('../assets/air_water_level_1/images/Images/airplane_level_1.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_7.mp3'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "isCorrect": false
        },
    ],
    // this is Set 4
    [
        {
            "id": 13,
            "big_img": require('../assets/air_water_level_1/images/Images/business jet_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_8.mp3'),
            "isCorrect": false
        },
        {
            "id": 14,
            "big_img": require('../assets/air_water_level_1/images/Images/rowboat_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_8.mp3'),
            "isCorrect": false
        },
        {
            "id": 15,
            "big_img": require('../assets/air_water_level_1/images/Images/sailboat_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_6.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_8.mp3'),
            "isCorrect": true
        },
        {
            "id": 16,
            "big_img": require('../assets/air_water_level_1/images/Images/ship_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_8.mp3'),
            "isCorrect": false
        },
    ],

    // this is Set 5
    [
        {
            "id": 17,
            "big_img": require('../assets/air_water_level_1/images/Images/yacht_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_3.mp3'),
            "isCorrect": false
        },
        {
            "id": 18,
            "big_img": require('../assets/air_water_level_1/images/Images/helicopter_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_3.mp3'),
            "isCorrect": false
        },
        {
            "id": 19,
            "big_img": require('../assets/air_water_level_1/images/Images/coracle_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_3.mp3'),
            "isCorrect": false
        },
        {
            "id": 20,
            "big_img": require('../assets/air_water_level_1/images/Images/ship_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_7.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_3.mp3'),
            "isCorrect": true
        },
    ],

    // this is Set 6 
    [
        {
            "id": 21,
            "big_img": require('../assets/air_water_level_1/images/Images/rowboat_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_8.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_9.mp3'),
            "isCorrect": true
        },
        {
            "id": 22,
            "big_img": require('../assets/air_water_level_1/images/Images/airplane_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_9.mp3'),
            "isCorrect": false
        },
        {
            "id": 23,
            "big_img": require('../assets/air_water_level_1/images/Images/hovercraft_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_9.mp3'),
            "isCorrect": false
        },
        {
            "id": 24,
            "big_img": require('../assets/air_water_level_1/images/Images/glider_level_1.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_9.mp3'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "isCorrect": false
        },
    ],
    // this is Set 7 
    [
        {
            "id": 25,
            "big_img": require('../assets/air_water_level_1/images/Images/ship_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_10.mp3'),
            "isCorrect": false
        },
        {
            "id": 26,
            "big_img": require('../assets/air_water_level_1/images/Images/airplane_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_10.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_10.mp3'),
            "isCorrect": true
        },
        {
            "id": 27,
            "big_img": require('../assets/air_water_level_1/images/Images/yacht_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_10.mp3'),
            "isCorrect": false
        },
        {
            "id": 28,
            "big_img": require('../assets/air_water_level_1/images/Images/sailboat_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_10.mp3'),
            "isCorrect": false
        },
    ],
    // this is Set 8 
    [
        {
            "id": 29,
            "big_img": require('../assets/air_water_level_1/images/Images/hovercraft_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_13.mp3'),
            "isCorrect": false
        },
        {
            "id": 30,
            "big_img": require('../assets/air_water_level_1/images/Images/helicopter_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_13.mp3'),
            "isCorrect": false
        },
        {
            "id": 31,
            "big_img": require('../assets/air_water_level_1/images/Images/glider_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_13.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_13.mp3'),
            "isCorrect": true
        },
        {
            "id": 32,
            "big_img": require('../assets/air_water_level_1/images/Images/ship_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_13.mp3'),
            "isCorrect": false
        },
    ],
    // this is Set 9 
    [
        {
            "id": 33,
            "big_img": require('../assets/air_water_level_1/images/Images/sailboat_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_11.mp3'),
            "isCorrect": false
        },
        {
            "id": 34,
            "big_img": require('../assets/air_water_level_1/images/Images/yacht_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_11.mp3'),
            "isCorrect": false
        },
        {
            "id": 35,
            "big_img": require('../assets/air_water_level_1/images/Images/glider_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_11.mp3'),
            "isCorrect": false
        },
        {
            "id": 36,
            "big_img": require('../assets/air_water_level_1/images/Images/helicopter_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_11.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_11.mp3'),

            "isCorrect": true
        }
    ],
    // this is Set 10 
    [
        {
            "id": 37,
            "big_img": require('../assets/air_water_level_1/images/Images/airplane_level_1.png'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_12.mp3'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "isCorrect": false
        },
        {
            "id": 38,
            "big_img": require('../assets/air_water_level_1/images/Images/business jet_level_1.png'),
            "correct_sound": require('../assets/common/audio/For_correct_answer.mp3'),
            "correct_answer": require('../assets/air_water_level_0/audio/VBWA_A_L0_12.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_12.mp3'),
            "green_tick": require('../assets/common/textures/interactions/Tick.png'),
            "isCorrect": true
        },
        {
            "id": 39,
            "big_img": require('../assets/air_water_level_1/images/Images/rowboat_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_12.mp3'),
            "isCorrect": false
        },
        {
            "id": 40,
            "big_img": require('../assets/air_water_level_1/images/Images/coracle_level_1.png'),
            "wrong_sound": require('../assets/common/audio/For_the_wrong_answer.mp3'),
            "find_vegetable": require('../assets/air_water_level_1/audio/VBWA_A_L1_12.mp3'),
            "isCorrect": false
        },
    ]
]