// LEVEL1 DEMO JSON

export const level1DemoData = {
    id: 1,
    image: require('../../assets/level-0/images/images/orange.png'),
    correct_image: require('../../assets/level-0/images/images/orange_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    hand_cusrsor: require('../../assets/common/textures/interactions/Hand_Cursor3.png'),

    // sound: require('../assets/air_water_level_0/audio/VBWA_A_L0_7.mp3'),
    // wrong_sound: require('../assets/common/audio/For_the_wrong_answer.mp3'),
    // correct_sound: require('../assets/common/audio/For_correct_answer.mp3'),
    // hand_cursor: require('../assets/common/textures/interactions/Hand_Cursor3.png'),
};


export const level1Data = [{
    id: 1,
    image: require('../../assets/level-0/images/images/cat.png'),
    correct_image: require('../../assets/level-0/images/images/cat_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_7.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'cat'

},
{
    id: 2,
    image: require('../../assets/level-0/images/images/pumpkin.png'),
    correct_image: require('../../assets/level-0/images/images/pumpkin_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_8.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'pumpkin'
},
{
    id: 3,
    image: require('../../assets/level-0/images/images/chair.png'),
    correct_image: require('../../assets/level-0/images/images/chair_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_9.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'chair'
},
{
    id: 4,
    image: require('../../assets/level-0/images/images/hand.png'),
    correct_image: require('../../assets/level-0/images/images/hand_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_10.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'hand'
},
{
    id: 5,
    image: require('../../assets/level-0/images/images/table.png'),
    correct_image: require('../../assets/level-0/images/images/table_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_9.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'table'
},
{
    id: 6,
    image: require('../../assets/level-0/images/images/horse.png'),
    correct_image: require('../../assets/level-0/images/images/horse_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_7.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'horse'
},
{
    id: 7,
    image: require('../../assets/level-0/images/images/eye.png'),
    correct_image: require('../../assets/level-0/images/images/eye_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_10.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'eye'
},
{
    id: 8,
    image: require('../../assets/level-0/images/images/carrot.png'),
    correct_image: require('../../assets/level-0/images/images/carrot_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_8.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'carrot'
},
{
    id: 9,
    image: require('../../assets/level-0/images/images/orange.png'),
    correct_image: require('../../assets/level-0/images/images/orange_word_card.png'),
    image_place_holder: require('../../assets/level-0/images/image_place_holder.png'),
    demarcation_line: require('../../assets/level-0/images/demarcation line.png'),
    mic_button: require('../../assets/level-0/images/mic_button.png'),
    question: require('../../assets/level-0/audio/SSM_A_L1_2.mp3'),
    answer: require('../../assets/level-0/audio/SSM_A_L1_5.mp3'),
    wrong_answer: require('../../assets/level-0/audio/SSM_A_L1_6.mp3'),
    text: 'orange'
},
]
