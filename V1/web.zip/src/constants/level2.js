// LEVEL2 DEMO JSON

export const level2DemoData = {
  id: 1,
  image: require('../../assets/level-2/images/images/hen.png'),
  correct_image: require('../../assets/level-2/images/images/hen_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  hand_cusrsor: require('../../assets/common/textures/interactions/Hand_Cursor3.png'),

}; 


export const level2Data = [{
  id: 1,
  image: require('../../assets/level-2/images/images/bus.png'),
  correct_image: require('../../assets/level-2/images/images/bus_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_7.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'bus'

},
{
  id: 2,
  image: require('../../assets/level-2/images/images/teacher.png'),
  correct_image: require('../../assets/level-2/images/images/teacher_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_8.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'teacher'
},
{
  id: 3,
  image: require('../../assets/level-2/images/images/shirt.png'),
  correct_image: require('../../assets/level-2/images/images/shirt_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_9.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'shirt'
},
{
  id: 4,
  image: require('../../assets/level-2/images/images/neem.png'),
  correct_image: require('../../assets/level-2/images/images/neem_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_10.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'neem'
},
{
  id: 5,
  image: require('../../assets/level-2/images/images/car.png'),
  correct_image: require('../../assets/level-2/images/images/car_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_7.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'car'
},
{
  id: 6,
  image: require('../../assets/level-2/images/images/doctor.png'),
  correct_image: require('../../assets/level-2/images/images/doctor_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_8.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'doctor'
},
{
  id: 7,
  image: require('../../assets/level-2/images/images/skirt.png'),
  correct_image: require('../../assets/level-2/images/images/skirt_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_9.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'skirt'
},
{
  id: 8,
  image: require('../../assets/level-2/images/images/tulsi.png'),
  correct_image: require('../../assets/level-2/images/images/tulsi_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_10.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'tulsi'
},
{
  id: 9,
  image: require('../../assets/level-2/images/images/hen.png'),
  correct_image: require('../../assets/level-2/images/images/hen_word_card.png'),
  image_place_holder: require('../../assets/level-2/images/image_place_holder.png'),
  demarcation_line: require('../../assets/level-2/images/demarcation line.png'),
  mic_button: require('../../assets/level-2/images/mic_button.png'),
  question: require('../../assets/level-2/audio/SSM_A_L2_2.mp3'),
  answer: require('../../assets/level-2/audio/SSM_A_L2_5.mp3'),
  wrong_answer: require('../../assets/level-2/audio/SSM_A_L2_6.mp3'),
  text: 'hen'
},
]
